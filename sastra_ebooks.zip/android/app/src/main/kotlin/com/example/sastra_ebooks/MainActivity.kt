package com.example.sastra_ebooks

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
