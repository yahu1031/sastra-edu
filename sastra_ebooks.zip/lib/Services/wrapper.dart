import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../Home/HomeScreen.dart';
import '../Services/authenticate.dart';
import '../Services/user.dart';

class Wrapper extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final user = Provider.of<User>(context);
    print(user);

    //Return to home or Authentication Widget
    if (user == null) {
      return Authenticate();
    } else {
      return Home();
    }
  }
}
