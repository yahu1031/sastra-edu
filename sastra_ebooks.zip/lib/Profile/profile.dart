// ignore: implementation_imports
import 'package:flutter/src/widgets/async.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:shimmer/shimmer.dart';

void main() => runApp(new Profile());

class Profile extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return new MaterialApp(
      home: new ProfileHome(),
    );
  }
}

class ProfileHome extends StatefulWidget {
  @override
  _ProfileHomeState createState() => _ProfileHomeState();
}

class _ProfileHomeState extends State<ProfileHome> {
  @override
  Widget build(BuildContext context) {
    return new Scaffold(
      appBar: new AppBar(
        elevation: 0.0,
        backgroundColor: Colors.transparent,
        title: new Shimmer.fromColors(
          baseColor: Colors.blue[500],
          highlightColor: Colors.lightBlueAccent,
          child: Container(
            margin: EdgeInsets.only(
              right: 30.0,
              left: 60.0,
            ),
            child: new Text(
              'Profile',
              style: GoogleFonts.pacifico(
                fontSize: 30.0,
              ),
            ),
          ),
        ),
      ),
      body: StreamBuilder(
        stream: Firestore.instance.collection('Data').snapshots(),
        builder: (BuildContext context, AsyncSnapshot snapshot) {
          if (!snapshot.hasData) {
            return Text("loading Data.. Please wait");
          }
          return ListView.builder(
              shrinkWrap: true,
              itemCount: snapshot.data.documents.length,
              padding: const EdgeInsets.only(top: 5.0),
              itemBuilder: (context, index) {
                DocumentSnapshot ds = snapshot.data.documents[index];
                return new Column(
                  textDirection: TextDirection.ltr,
                  children: <Widget>[
                    Text(
                      ds["name"],
                      style: GoogleFonts.notoSans(
                          fontSize: 20.0, color: Colors.black),
                    ),
                    Text(
                      ds["year"],
                      style: GoogleFonts.notoSans(
                          fontSize: 20.0,
                          color: Colors.lightBlueAccent,
                          fontWeight: FontWeight.bold),
                    ),
                    Text(
                      ds["regNo"].toString(),
                      style: GoogleFonts.notoSans(
                          fontSize: 15.0, color: Colors.black),
                    ),
                  ],
                );
              });
        },
      ),
    );
  }
}

//class Profile extends StatefulWidget {
//  @override
//  _ProfileState createState() => _ProfileState();
//}
//
//class _ProfileState extends State<Profile> {
//  @override
//  Widget build(BuildContext context) {
//    return Scaffold(
//      backgroundColor: backgroundColor,
//      body: StreamBuilder(
//        stream: Firestore.instance.collection('data').snapshots(),
//        builder: (context, snapshot) {
//          if (!snapshot.hasData) return Text("loading Data.. Please wait");
//          return Container(
//            child: Column(
//              children: <Widget>[
//                Text(
//                  snapshot.data.documnets[0]['name'],
//                  style: GoogleFonts.notoSans(fontSize: 20.0),
//                ),
//                SizedBox(height: 20.0),
//                Text(
//                  snapshot.data.documnets[0]['regNo'].toString(),
//                  style: GoogleFonts.notoSans(fontSize: 10.0),
//                ),
//                SizedBox(height: 20.0),
//                Text(
//                  snapshot.data.documnets[0]['year'],
//                  style: GoogleFonts.notoSans(
//                      fontSize: 25.0,
//                      color: Colors.lightBlueAccent,
//                      fontWeight: FontWeight.bold),
//                ),
//              ],
//            ),
//          );
//        },
//      ),
//    );
//  }
//}
